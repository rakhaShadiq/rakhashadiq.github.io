# Contributing to nanogallery2  

First off, thanks for taking the time to contribute!  
  
  
## Pull request
PR should only be made with the branch `DEV`.  
Source code is in the `src` folder.  
The content of the `dist` folder is generated, please don't edit anything in it.  
  
## Issue  
Provide as much details as possible.  
A Codepen is much appreciated. It will help resolve your issue quicker.  




